#include <iostream>
#include <string>

#include "State.h"
#include "Traveller.h"
#include "AirMovement.h"
#include "BicycleMovement.h"
#include "CarMovement.h"
#include "FootMovement.h"
#include "TrainMovement.h"

#include "Route.h"
#include "BestRoute.h"
#include "CheaperRoute.h"
#include "FastestRoute.h"
#include "ScenicRoute.h"
#include "ShortestRoute.h"

#include "WorldBuilder.h"
#include "CityFactory.h"
#include "ForestFactory.h"
#include "DesertFactory.h"
#include "OceanFactory.h"
#include "NPC.h"

#include "Map.h"
#include "Location.h"
#include "Quest.h"
#include "Toll.h"
#include "Weather.h"

#include "Region.h"


int main()
{
    // ============================================================
    // STATE PATTERN
    // ============================================================

    std::cout << "================ STATE PATTERN ================\n";

    Traveller* traveller = new Traveller();

    traveller->setState(new AirMovement());

    std::cout << "Starting movement: "
              << traveller->getState()->getType() << "\n";

    traveller->change("BicycleMovement");

    std::cout << "Changed movement: "
              << traveller->getState()->getType() << "\n";

    traveller->change("CarMovement");

    std::cout << "Changed movement: "
              << traveller->getState()->getType() << "\n";

    traveller->change("FootMovement");

    std::cout << "Changed movement: "
              << traveller->getState()->getType() << "\n";

    traveller->change("TrainMovement");

    std::cout << "Changed movement: "
              << traveller->getState()->getType() << "\n";

    delete traveller;


    // ============================================================
    // STRATEGY PATTERN
    // ============================================================

    std::cout << "\n================ STRATEGY PATTERN ================\n";

    Route* route = new Route();

    route->setStrategy(new BestRoute());
    route->getRoute()->useRoute();

    route->setStrategy(new CheaperRoute());
    route->getRoute()->useRoute();

    route->setStrategy(new FastestRoute());
    route->getRoute()->useRoute();

    route->setStrategy(new ScenicRoute());
    route->getRoute()->useRoute();

    route->setStrategy(new ShortestRoute());
    route->getRoute()->useRoute();

    delete route;


    // ============================================================
    // ABSTRACT FACTORY
    // ============================================================

    std::cout << "\n================ ABSTRACT FACTORY ================\n";

    WorldBuilder* cityFactory = new CityFactory();
    WorldBuilder* forestFactory = new ForestFactory();
    WorldBuilder* desertFactory = new DesertFactory();
    WorldBuilder* oceanFactory = new OceanFactory();

    NPC* cityNPC = cityFactory->createNPC();
    NPC* forestNPC = forestFactory->createNPC();
    NPC* desertNPC = desertFactory->createNPC();
    NPC* oceanNPC = oceanFactory->createNPC();

    cityNPC->observe();
    forestNPC->observe();
    desertNPC->observe();
    oceanNPC->observe();

    delete cityNPC;
    delete forestNPC;
    delete desertNPC;
    delete oceanNPC;

    delete cityFactory;
    delete forestFactory;
    delete desertFactory;
    delete oceanFactory;


    // ============================================================
    // DECORATOR PATTERN
    // ============================================================

    std::cout << "\n================ DECORATOR PATTERN ================\n";

    // Base component
    Map* location1 = new Location();

    // Decorate it progressively
    Map* questLocation = new Quest(location1);
    Map* tollQuestLocation = new Toll(questLocation);
    Map* weatherTollQuestLocation = new Weather(tollQuestLocation);


    // Another valid combination
    Map* location2 = new Location();

    Map* tollLocation = new Toll(location2);
    Map* weatherTollLocation = new Weather(tollLocation);


    // Another valid combination
    Map* location3 = new Location();

    Map* questLocation3 = new Quest(location3);
    Map* tollQuestLocation3 = new Toll(questLocation3);


    // ============================================================
    // COMPOSITE PATTERN
    // ============================================================

    std::cout << "\n================ COMPOSITE PATTERN ================\n";

    Region* region = new Region();

    region->add(weatherTollQuestLocation);
    region->add(weatherTollLocation);
    region->add(tollQuestLocation3);

    delete region;


    return 0;
}